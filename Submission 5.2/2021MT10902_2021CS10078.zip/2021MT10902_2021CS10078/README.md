Used inbuilt logistic regression, solver = 'liblinear' along with L2 regularization.
Set max_depth = 20 and min_samples_split = 100